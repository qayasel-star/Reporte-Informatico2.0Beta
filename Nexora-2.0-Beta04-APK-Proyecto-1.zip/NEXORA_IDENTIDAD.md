# Nexora — identidad de la aplicación

- Nombre visible: Nexora
- Descripción: Gestión inteligente de soporte técnico
- Eslogan: Cada incidencia bajo control
- Versión: 2.0-beta04
- Identificador Android conservado: `com.registroinformatico.app`

El identificador se mantiene deliberadamente para conservar la continuidad de instalación y actualización del proyecto. La compatibilidad real de actualización también depende de que el APK se firme con la misma clave.

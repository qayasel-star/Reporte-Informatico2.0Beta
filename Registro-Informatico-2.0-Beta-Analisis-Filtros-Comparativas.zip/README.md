# Registro Informático 2.0 Beta — auditoría del proyecto

Proyecto Android Kotlin + Jetpack Compose. Identificador: `com.registroinformatico.app`.
Versión declarada: `2.0-beta02` (`versionCode = 4`).

## Funciones encontradas en el código
- Pantallas Inicio, Reportes, Análisis, Informes y Ajustes.
- Almacenamiento local de reportes en SharedPreferences como JSON.
- Alta/edición, búsqueda, filtrado, cambio de estado y eliminación de reportes.
- ID visible calculado a partir del timestamp del reporte.
- Selección de técnico (Yasel, Getma, Naybet, Yanelis y Selene).
- Registro de fecha de apertura y cierre, y cálculo de duración para reportes resueltos.
- Análisis por período, estado, departamento, software/equipo, prioridad y técnico.
- Exportación CSV y copia/restauración JSON según las funciones del código.
- Splash nativo y pantalla de bienvenida Compose.

## Limitaciones verificadas en la revisión estática
- La compilación real no se ejecutó en este entorno; debe validarse con GitHub Actions.
- Las notificaciones periódicas cada dos horas no están implementadas: el botón actual abre un diálogo informativo.
- El proyecto usa la firma debug predeterminada; todavía no está conectada una clave de firma permanente.
- El modelo conserva el campo interno `type` para compatibilidad con registros anteriores, aunque el formulario actual no lo solicita.
- El almacenamiento local no es una base de datos Room; desinstalar la app puede borrar los datos locales. Exportar una copia de seguridad antes de instalar versiones que puedan exigir desinstalación.
- El filtro “30 días” se basa en la fecha de apertura del reporte, por lo que puede excluir un caso abierto hace más de 30 días aunque se haya cerrado recientemente.

## Compilar en GitHub Actions desde la raíz del repositorio
1. Extrae este ZIP. Los archivos `settings.gradle.kts`, `build.gradle.kts`, `app/` y `.github/` deben quedar directamente en la raíz del repositorio, no dentro de una subcarpeta adicional.
2. Sube los archivos a GitHub conservando la estructura de carpetas.
3. Abre Actions y ejecuta el workflow **Compilar APK Android 2.0 Beta**.
4. Descarga el artefacto `Registro-Informatico-2.0-Beta-APK` cuando la ejecución termine correctamente.
5. No instales una versión sobre la existente hasta confirmar que la firma coincide y que la versión compila.

## Firma y actualizaciones
Android exige el mismo `applicationId`, un certificado de firma compatible y un `versionCode` igual o superior para aceptar una actualización normal. La clave privada debe guardarse de forma segura y no subirse al repositorio.

## Estado
Este ZIP corrige la estructura de empaquetado para que el proyecto esté en la raíz del archivo. No significa que la compilación o las pruebas en dispositivo hayan sido ejecutadas; eso sigue pendiente de verificar.
